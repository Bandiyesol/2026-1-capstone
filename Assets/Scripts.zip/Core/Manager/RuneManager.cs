using System.Collections.Generic;
using UnityEngine;

public class RuneManager : MonoBehaviour
{
    public static RuneManager instance;

    public bool IsCurrentCombinationValid { get; private set; } = true;
    public string CurrentWarningMessage { get; private set; } = string.Empty;

    /// <summary>
    /// 룬 쿨타임 배율. 기본값 1f.
    /// 특수 물약 사용 시 PotionEffect가 0.5f로 설정 → 쿨타임 절반.
    /// </summary>
    public float CooldownMultiplier { get; set; } = 1f;

    const int BaseSlotCount = 3;
    const int MaxSlotCount  = 6;   // 고대 문양 최대 3개 중첩

    // ExtraRuneSlot 악세사리로 동적 확장 가능
    int extraSlots = 0;
    int SlotCount  => Mathf.Min(BaseSlotCount + extraSlots, MaxSlotCount);

    RuneData[] slots = new RuneData[MaxSlotCount];
    readonly List<RuneData> activeRunesCache = new List<RuneData>();

    [SerializeField] RuneData[] initialRunes = new RuneData[3];

    void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;

        for (int i = 0; i < initialRunes.Length; i++)
        {
            if (initialRunes[i] != null)
                SetRune(i, initialRunes[i]);
        }
    }

    public void SetRune(int slotIndex, RuneData data)
    {
        if (slotIndex < 0 || slotIndex >= SlotCount) return;

        if (data != null)
        {
            for (int i = 0; i < SlotCount; i++)
            {
                if (i != slotIndex && slots[i] == data)
                    slots[i] = null;
            }
        }

        slots[slotIndex] = data;
        Validate();
    }

    public void SwapSlots(int a, int b)
    {
        if (a < 0 || a >= SlotCount || b < 0 || b >= SlotCount) return;
        (slots[a], slots[b]) = (slots[b], slots[a]);
        Validate();
    }

    public void ClearSlot(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= SlotCount) return;
        slots[slotIndex] = null;
        Validate();
    }

    public void ClearAll()
    {
        for (int i = 0; i < SlotCount; i++)
            slots[i] = null;
        Validate();
    }

    public void ResetToInitial()
    {
        ClearAll();

        if (initialRunes == null)
            return;

        for (int i = 0; i < initialRunes.Length && i < SlotCount; i++)
        {
            if (initialRunes[i] != null)
                SetRune(i, initialRunes[i]);
        }
    }

    public List<RuneData> GetActiveRunes()
    {
        activeRunesCache.Clear();
        for (int i = 0; i < SlotCount; i++)
        {
            if (slots[i] != null)
                activeRunesCache.Add(slots[i]);
        }

        return activeRunesCache;
    }

    void Validate()
    {
        if (!RuneValidator.ValidateSlots(slots, out string slotError))
        {
            IsCurrentCombinationValid = false;
            CurrentWarningMessage = slotError;
            return;
        }

        var active = GetActiveRunes();
        IsCurrentCombinationValid = RuneValidator.IsValidCombination(active, out string comboError);
        CurrentWarningMessage = IsCurrentCombinationValid
            ? string.Empty
            : (string.IsNullOrEmpty(comboError)
                ? RuneValidator.GetWarningMessage(active)
                : comboError);

        if (!IsCurrentCombinationValid)
            Debug.LogWarning($"[RuneManager] {CurrentWarningMessage}");
    }

    public RuneData GetSlot(int i) => (i >= 0 && i < SlotCount) ? slots[i] : null;
    public int SlotCount_ => SlotCount;

    /// <summary>[악세사리] 룬 슬롯 1개 추가. 최대 MaxSlotCount까지.</summary>
    public void AddExtraSlot()
    {
        if (BaseSlotCount + extraSlots >= MaxSlotCount) return;
        extraSlots++;
        Debug.Log($"[RuneManager] 룬 슬롯 확장 → {SlotCount}칸");
    }

    public int GetFilledSlotCount()
    {
        int count = 0;
        for (int i = 0; i < SlotCount; i++)
        {
            if (slots[i] != null)
                count++;
        }

        return count;
    }

    public bool IsFull => GetFilledSlotCount() >= SlotCount;

    /// <summary>첫 빈 슬롯에 룬을 추가합니다.</summary>
    public bool TryAddRune(RuneData data)
    {
        if (data == null)
            return false;

        for (int i = 0; i < SlotCount; i++)
        {
            if (slots[i] != null)
                continue;

            SetRune(i, data);
            return true;
        }

        return false;
    }
}